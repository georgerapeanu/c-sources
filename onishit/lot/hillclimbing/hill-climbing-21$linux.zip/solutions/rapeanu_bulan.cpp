#include <bits/stdc++.h>
#include "cetatuie.h"

using namespace std;

long long solve(int n, long long k, int v[]){
  return 0;
}
