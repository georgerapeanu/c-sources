long long solve(int N, long long K, int V[]);
