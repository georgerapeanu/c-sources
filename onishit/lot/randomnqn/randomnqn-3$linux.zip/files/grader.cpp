#include <bits/stdc++.h>
#include "ghinion.h"

int main(){
  int n, m;
  scanf("%d %d", &n, &m);

  printf("%d\n", solve(n, m));

  return 0;
}
