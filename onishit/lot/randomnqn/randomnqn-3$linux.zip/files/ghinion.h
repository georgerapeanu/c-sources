int solve(int N, int M);
